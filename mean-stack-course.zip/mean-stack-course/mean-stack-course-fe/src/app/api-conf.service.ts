import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import TaskListModel from './models/taskListModel';
import TaskModel from './models/taskModel';

@Injectable({
  providedIn: 'root',
})
export class ApiConfService {
  API_BASE_URL = 'http://localhost:3000';

  constructor(private httpClient: HttpClient) {}

  // get API call
  getTaskLists(url: string) {
    return this.httpClient.get<TaskListModel[]>(`${this.API_BASE_URL}/${url}`);
  }

  // get API call
  getTasks(url: string) {
    return this.httpClient.get<TaskModel[]>(`${this.API_BASE_URL}/${url}`);
  }

  // post API call
  postTaskList(url: string, data: Object) {
    return this.httpClient.post<TaskListModel>(
      `${this.API_BASE_URL}/${url}`,
      data
    );
  }

  // post API call
  postTask(url: string, data: Object) {
    return this.httpClient.post<TaskModel>(`${this.API_BASE_URL}/${url}`, data);
  }

  // put API call
  put(url: string, data: Object) {
    return this.httpClient.put(`${this.API_BASE_URL}/${url}`, data);
  }
  // delete API call
  deleteTaskList(url: string) {
    return this.httpClient.delete<TaskListModel>(`${this.API_BASE_URL}/${url}`);
  }

  // delete API call
  deleteTask(url: string) {
    return this.httpClient.delete<TaskModel>(`${this.API_BASE_URL}/${url}`);
  }

  // patch API call
  patch(url: string, data: Object) {
    return this.httpClient.patch(`${this.API_BASE_URL}/${url}`, data);
  }
}
