class TaskListModel {
  _id!: string;
  title!: string;
}

export default TaskListModel;
