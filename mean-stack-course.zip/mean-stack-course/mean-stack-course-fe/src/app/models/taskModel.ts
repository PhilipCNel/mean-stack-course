class TaskModel {
  _id!: string;
  title!: string;
  _taskListId!: string;
  completed!: boolean;
}

export default TaskModel;
