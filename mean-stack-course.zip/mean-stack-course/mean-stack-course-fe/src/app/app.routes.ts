import { Routes } from '@angular/router';
import { TaskScreenComponent } from './screens/task-screen/task-screen.component';
import { NewTasklistScreenComponent } from './screens/new-tasklist-screen/new-tasklist-screen.component';
import { NewTaskScreenComponent } from './screens/new-task-screen/new-task-screen.component';

export const routes: Routes = [
  { path: '', redirectTo: 'task-list', pathMatch: 'full' },
  { path: 'task-list', component: TaskScreenComponent },
  { path: 'task-list/:taskListId', component: TaskScreenComponent },
  { path: 'new-task-list', component: NewTasklistScreenComponent },
  { path: 'task-list/:taskListId/new-task', component: NewTaskScreenComponent },
];
