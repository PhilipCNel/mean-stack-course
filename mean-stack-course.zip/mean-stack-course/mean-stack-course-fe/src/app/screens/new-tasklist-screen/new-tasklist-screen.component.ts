import { Component } from '@angular/core';
import { TaskService } from '../../task.service';
import { Router, RouterLink } from '@angular/router';
import TaskListModel from '../../models/taskListModel';

@Component({
  selector: 'app-new-tasklist-screen',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './new-tasklist-screen.component.html',
  styleUrl: './new-tasklist-screen.component.css',
})
export class NewTasklistScreenComponent {
  constructor(private taskService: TaskService, private router: Router) {}

  ngOnInit(): void {}

  addNewTaskList(title: string) {
    if (title) {
      this.taskService
        .createTaskList(title)
        .subscribe((newlyCreatedTaskList: TaskListModel) => {
          this.router.navigate(['/task-list', newlyCreatedTaskList._id]);
        });
    } else {
      alert('Title cannot be empty');
      return;
    }
  }
}
