import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewTasklistScreenComponent } from './new-tasklist-screen.component';

describe('NewTasklistScreenComponent', () => {
  let component: NewTasklistScreenComponent;
  let fixture: ComponentFixture<NewTasklistScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NewTasklistScreenComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NewTasklistScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
