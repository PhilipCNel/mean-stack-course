import { Component } from '@angular/core';
import { ActivatedRoute, Params, Router, RouterLink } from '@angular/router';
import { TaskService } from '../../task.service';

@Component({
  selector: 'app-new-task-screen',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './new-task-screen.component.html',
  styleUrl: './new-task-screen.component.css',
})
export class NewTaskScreenComponent {
  taskListId: string = '';

  constructor(
    private taskService: TaskService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.activatedRoute.params.subscribe((params: Params) => {
      this.taskListId = params['taskListId'];
    });
  }

  ngOnInit(): void {}

  addNewTask(title: string) {
    const taskListId = this.router.url.split('/').pop();
    this.taskService.createTaskInList(title, this.taskListId).subscribe(() => {
      this.router.navigate(['../'], { relativeTo: this.activatedRoute });
    });
  }
}
