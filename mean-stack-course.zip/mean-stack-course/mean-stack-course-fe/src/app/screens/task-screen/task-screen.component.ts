import { Component, OnInit } from '@angular/core';
import TaskListModel from '../../models/taskListModel';
import TaskModel from '../../models/taskModel';
import { TaskService } from '../../task.service';
import { NgFor, CommonModule, NgStyle } from '@angular/common';
import {
  ActivatedRoute,
  Params,
  Router,
  RouterLink,
  RouterModule,
} from '@angular/router';

@Component({
  selector: 'app-task-screen',
  standalone: true,
  imports: [NgFor, CommonModule, NgStyle, RouterLink, RouterModule],
  templateUrl: './task-screen.component.html',
  styleUrl: './task-screen.component.css',
})
export class TaskScreenComponent implements OnInit {
  // Define arrays
  taskLists: TaskListModel[] = [];
  tasks: TaskModel[] = [];
  taskListId: string = '';
  // Constructor runs on the instantiation of the component
  constructor(
    private taskService: TaskService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {}

  // this is called when the component is loaded
  ngOnInit(): void {
    // get all task lists
    this.taskService.getTaskLists().subscribe((allTaskLists) => {
      this.taskLists = allTaskLists;
    });

    // get all tasks of a task list
    // the params observable emits a new value every time the route parameters change
    // therefore by subscribing to it, the code in the subscribe block will run every time the route parameters change
    this.activatedRoute.params.subscribe((params: Params) => {
      this.taskListId = params['taskListId'];

      if (this.taskListId) {
        this.taskService
          .getTasks(this.taskListId)
          .subscribe((tasks: TaskModel[]) => (this.tasks = tasks));
      }
    });
  }

  taskClicked(task: TaskModel) {
    this.taskService
      .updateTaskStatus(this.taskListId, task)
      .subscribe(() => (task.completed = !task.completed));
  }

  taskListClicked(taskList: TaskListModel) {
    this.router.navigate(['/task-list', taskList._id]);
  }

  deleteTask(task: TaskModel) {
    this.taskService.deleteTask(this.taskListId, task._id).subscribe(() => {
      this.tasks = this.tasks.filter((t) => t._id !== task._id);
    });
  }

  deleteTaskList(taskList: TaskListModel) {
    this.taskService.deleteTaskList(taskList._id).subscribe(() => {
      this.taskLists = this.taskLists.filter((t) => t._id !== taskList._id);
    });
  }

  newTask() {
    if (!this.taskListId) {
      alert('Please select a task list');
      return;
    } else {
      this.router.navigate(['/task-list', this.taskListId, 'new-task']);
    }
  }
}
