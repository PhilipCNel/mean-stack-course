import { Injectable } from '@angular/core';
import { ApiConfService } from './api-conf.service';
import TaskModel from './models/taskModel';
import { Observable } from 'rxjs';
import TaskListModel from './models/taskListModel';

// This decorator is used to define a class as a service in Angular.
// When we inject this into a component, Angular will create an instance of this class and inject it into the component.
// Then we can use the class's methods and properties in the component.
@Injectable({
  providedIn: 'root',
})
export class TaskService {
  constructor(private apiConfigService: ApiConfService) {}

  // get all task lists
  getTaskLists(): Observable<TaskListModel[]> {
    return this.apiConfigService.getTaskLists('taskLists');
  }

  // create a new task list
  createTaskList(title: string): Observable<TaskListModel> {
    let data = {
      title: title,
    };
    return this.apiConfigService.postTaskList('taskLists', data);
  }

  // get all tasks of a task list
  // http://localhost:3000/taskLists/:taskListId/tasks => [ {Task}, {Task}, ...]
  getTasks(taskListId: string): Observable<TaskModel[]> {
    return this.apiConfigService.getTasks('taskLists/' + taskListId + '/tasks');
  }

  // create task in specific task list
  // http://localhost:3000/taskLists/:taskListId/tasks => {Task}
  createTaskInList(title: string, taskListId: string): Observable<TaskModel> {
    return this.apiConfigService.postTask(`taskLists/${taskListId}/tasks`, {
      title,
    });
  }

  // delete task list
  // http://localhost:3000/taskLists/:taskListId => {TaskList}
  deleteTaskList(taskListId: string): Observable<TaskListModel> {
    return this.apiConfigService.deleteTaskList('taskLists/' + taskListId);
  }

  // delete task inside a task list
  // http://localhost:3000/taskLists/:taskListId/tasks/:taskId => {Task}
  deleteTask(taskListId: string, taskId: string): Observable<TaskModel> {
    return this.apiConfigService.deleteTask(
      'taskLists/' + taskListId + '/tasks/' + taskId
    );
  }

  // update task status
  // http://localhost:3000/taskLists/:taskListId/tasks/:taskId => {Task}
  updateTaskStatus(taskListId: string, taskObject: TaskModel) {
    let updateData = {
      completed: !taskObject.completed, // toggle the status
    };
    return this.apiConfigService.patch(
      'taskLists/' + taskListId + '/tasks/' + taskObject._id,
      updateData
    );
  }
}
