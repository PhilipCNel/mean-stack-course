// ================ IMPORTS ================
// import express
const express = require('express');
// import mongoose
const mongoose = require('./database/mongoose');
// import task list model
const TaskList = require('./database/models/taskList');
// import task model
const Task = require('./database/models/task');

// ================ App creation ================
// initialise express application
const app = express();

// CORS - cross origin resource sharing
/*
backend - http://localhost:3000
frontend - http://localhost:4200
need to allow frontend to access backend
*/
// app.use is a method used to mount middleware functions to a specified path
// middleware functions have access to the request object, response object and the next function
// any IP, with any request type, with any headers can send a request to the backend
app.use(
  (req, res, next) => {
    // website you wish to allow to connect
    res.header('Access-Control-Allow-Origin', '*');
    // request types methods you wish to allow
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    // request headers you wish to allow
    // res.header('Access-Control-Allow-Headers', 'Origin', 'X-Requested-With', 'Content-Type', 'Accept');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    //
    next();
  }
)
// the next middleware function is:
// allow express to parse json data
app.use(express.json());

// ================================================
// ================ Route handlers ================
// ================================================


// ================ Task list calls ===============

// GET all task lists
// http://localhost:3000/taskLists => [ {TaskList}, {TaskList}, ...]
app.get('/taskLists', (req, res) => {
  // search TaskList model with no filtering
  TaskList.find({})
    // use promise which waits for the data to be fetched
    .then((taskLists) => {res.send(taskLists)})
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error)
      res.status(500);
    });
  });

// GET one task list
// http://localhost:3000/taskLists/:taskListId => {TaskList}
app.get('/taskLists/:taskListId', (req, res) => {
  // get the task list id
  const taskListId = req.params.taskListId;
  // search TaskList model with the task list id
  TaskList.find({_id: taskListId})
    // use promise which waits for the data to be fetched
    .then((taskList) => {res.status(200).send(taskList)})
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error)
      res.status(500);
    });
});

// POST a task list
// http://localhost:3000/taskLists => {TaskList}
app.post('/taskLists', (req, res) => {

  // create a new task list object
  taskListObject = {'title': req.body.title};
  // create a new task list
  TaskList(taskListObject)
    // save the task list
    .save()
    // use promise which waits for the data to be saved
    .then((taskList) => {res.status(201).send(taskList)})
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error);
      res.status(500);
    });
});

// UPDATE one task list with PUT, PUT is full update, PATCH is partial update
// http://localhost:3000/taskLists/:taskListId => {TaskList}
app.put('/taskLists/:taskListId', (req, res) => {
  // get the task list id
  const taskListId = req.params.taskListId;
  // update the task list with the task list id
  // TaskList.findOneAndUpdate returns a promise
  TaskList.findOneAndUpdate({_id: taskListId}, {$set: req.body}, {new: true})
    // on promise returned asynchronously, implement callback function with promise's return as input
    .then((taskList) => {
      res.status(200).send(taskList); // send status 200 for successful update
    })
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error);
      res.status(500).send(error); // send status 500 for server error
    });
});

// DELETE one task list
// http://localhost:3000/taskLists/:taskListId => {TaskList}
app.delete('/taskLists/:taskListId', (req, res) => {

  // get the task list id
  const taskListId = req.params.taskListId;

  // write a function that receives a taskListId and deletes all tasks with that taskListId
  const deleteAllTasksFromTaskList = (taskListId) => {
    Task.deleteMany({_taskListId: taskListId})
      .then(() => {return taskList;})
      .catch((error) => {console.log(error);});
  }

  // delete the task list with the task list id
  const responseTaskList = TaskList.findByIdAndDelete(taskListId)
    // on promise returned asynchronously, implement callback function with promise's return as input
    .then((taskList) => {
      deleteAllTasksFromTaskList(taskListId);
    })
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error);
      res.status(500).send(error); // send status 500 for server error
    });

    res.status(200).send(responseTaskList);
});

// ================ Task calls ===============

// create one task with one task list
// http://localhost:3000/taskLists/:taskListId/tasks => {Task}
app.post('/taskLists/:taskListId/tasks', (req, res) => {
  // get the task list id
  const taskListId = req.params.taskListId;
  // create a new task object
  taskObject = {'title': req.body.title, 
                '_taskListId': taskListId
  };
  // create a new task
  Task(taskObject)
    // save the task
    .save()
    // use promise which waits for the data to be saved
    .then((task) => {res.status(201).send(task)})
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error);
      res.status(500);
    });
});

// get all tasks for specific task list
// http://localhost:3000/taskLists/:taskListId/tasks => [ {Task}, {Task}, ...]
app.get('/taskLists/:taskListId/tasks', (req, res) => {
  // get the task list id
  const taskListId = req.params.taskListId;
  // search Task model with the task list id
  Task.find({_taskListId: taskListId})
    // use promise which waits for the data to be fetched
    .then((tasks) => {res.send(tasks)})
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error)
      res.status(500);
    });
});

// get one task
// http://localhost:3000/tasks/:taskId => {Task}
app.get('/tasks/:taskId', (req, res) => {
  // get the task id
  const taskId = req.params.taskId;
  // search Task model with the task id
  Task.findOne({_id: taskId})
    // use promise which waits for the data to be fetched
    .then((task) => {res.status(200).send(task)})
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error)
      res.status(500);
    });
});

// update one task from one task list
// http://localhost:3000/taskLists/:taskListId/tasks/:taskId => {Task}
app.put('/taskLists/:taskListId/tasks/:taskId', (req, res) => {
  // get the task id
  const taskId = req.params.taskId;
  // update the task with the task id
  // Task.findOneAndUpdate returns a promise
  Task.findOneAndUpdate({_id: taskId}, {$set: req.body}, {new: true})
    // on promise returned asynchronously, implement callback function with promise's return as input
    .then((task) => {
      res.status(200).send(task); // send status 200 for successful update
    })
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error);
      res.status(500).send(error); // send status 500 for server error
    });
});

// patch one task from one task list
// THIS IS EXACTLY THE SAME AS PUT AT THE MOMENT, DON'T KNOW HOW TO IMPLEMENT THE DIFFERENCE CORRECTLY, DON'T KNOW WHETHER THERE SHOULD BE A DIFFERENCE
// http://localhost:3000/taskLists/:taskListId/tasks/:taskId => {Task}
app.patch('/taskLists/:taskListId/tasks/:taskId', (req, res) => {
  // get the task id
  const taskId = req.params.taskId;
  // update the task with the task id
  // Task.findOneAndUpdate returns a promise
  Task.findOneAndUpdate({_id: taskId}, {$set: req.body}, {new: true})
    // on promise returned asynchronously, implement callback function with promise's return as input
    .then((task) => {
      res.status(200).send(task); // send status 200 for successful update
    })
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error);
      res.status(500).send(error); // send status 500 for server error
    });
});

// delete one task from one task list
// http://localhost:3000/taskLists/:taskListId/tasks/:taskId => {Task}
app.delete('/taskLists/:taskListId/tasks/:taskId', (req, res) => {
  // get the task id
  const taskId = req.params.taskId;
  const taskListId = req.params.taskListId;
  // delete the task with the task id
  Task.findOneAndDelete({_taskListId: taskListId, _id: taskId})
    // on promise returned asynchronously, implement callback function with promise's return as input
    .then((task) => {
      res.status(200).send(task); // send status 200 for successful deletion
    })
    // use promise which waits for the error to be caught
    .catch((error) => {
      console.log(error);
      res.status(500).send(error); // send status 500 for server error
    });
});

// ================================================
// ================ App listen ====================
// ================================================

// listen to port 3000
// port number, callback function
app.listen(3000, () => {
  console.log('Server is running on port 3000 woohoo');
});


