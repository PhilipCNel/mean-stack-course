const mongoose = require('mongoose');

// define the schema of the mongo collection
const TaskSchema = new mongoose.Schema({
    title: {
        type: String,
        trim: true,
        minLength: 3,
    },
    _taskListId: {
        type: mongoose.Types.ObjectId,
        required: true,
    },
    completed: {
        type: Boolean,
        default: false,
    },
});

// create a model which uses the above defined schema
const Task = mongoose.model('Task', TaskSchema);

module.exports = Task;