const mongoose = require('mongoose');

// define the schema of the mongo collection
const TaskListSchema = new mongoose.Schema({
    title: {
        type: String,
        trim: true,
        minLength: 3,
    }
});

// create a model which uses the above defined schema
const TaskList = mongoose.model('TaskList', TaskListSchema);

module.exports = TaskList;