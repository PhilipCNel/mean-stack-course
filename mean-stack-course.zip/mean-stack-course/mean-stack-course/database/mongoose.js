// import mongoose
const mongoose = require('mongoose');
// set mongoose to use the native JS promise library to handle asynchronous operations
mongoose.Promise = global.Promise;
// connect to the database
mongoose.connect('mongodb://127.0.0.1:27017/taskmanagerdb', { useNewUrlParser: true, useUnifiedTopology: true })
    // because we are using the JS promise library, this connection will run in parallel with other requests
    .then(() => {console.log('Connected to the database')})
    // if there is an error connecting to the database, log the error to the console
    .catch((error) => {console.log(error)});

// export the mongoose object that we've created
module.exports = mongoose;